# Django-kibru
Django kibru (kibruy Admin)


Installation
pip install django-kibru

Features
Search bar for any given model admin
Bootstrap 4 & AdminLTE UI components
Using the latest adminlte + bootstrap
Responsive


Screenshots

Login
<img width="430" alt="Login" src="https://user-images.githubusercontent.com/87245699/221366411-3170dc75-6c95-4016-86ea-233b2daf1307.png">
Dashboard 
<img width="957" alt="Dashboards" src="https://user-images.githubusercontent.com/87245699/221366429-c52dd816-272f-4c7b-b559-6db27edcce1a.png">

