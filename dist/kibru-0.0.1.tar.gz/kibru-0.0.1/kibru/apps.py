from __future__ import unicode_literals

from django.apps import AppConfig

__all__ = ["KibruConfig"]


class KibruConfig(AppConfig):
   
    name = "kibru"
    label = "kibru"
    verbose_name = "Kibru"
